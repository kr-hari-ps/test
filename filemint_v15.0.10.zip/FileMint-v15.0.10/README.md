<div style="text-align: center;">

  <!-- Main Banner -->
  <img src="assets/banners/filemint_github_banner.png" alt="FileMint Header Banner" width="1376" />

  <br/><br/>

  <!-- Badges -->
  <a href="https://github.com"><img src="https://img.shields.io/badge/Version-v15.0-00E5FF?style=for-the-badge&logo=github" alt="Version"></a>
  <a href="https://python.org"><img src="https://img.shields.io/badge/Python-3.12-3776AB?style=for-the-badge&logo=python&logoColor=white" alt="Python"></a>
  <a href="https://www.gnu.org/licenses/"><img src="https://img.shields.io/badge/License-MIT-green?style=for-the-badge" alt="License"></a>
  <a href="#"><img src="https://img.shields.io/badge/Platform-Linux%20%7C%20Windows-blue?style=for-the-badge&logo=linux" alt="Platform"></a>
  <a href="#"><img src="https://img.shields.io/badge/Dependencies-Zero-brightgreen?style=for-the-badge" alt="Zero Dependencies"></a>

  <br/><br/>

  <h3>⚡ Zero-Dependency Data Sanitization & Codebase Archiving Engine</h3>
  <p>A high-performance desktop utility for offline file consolidation, metadata cleaning, versioning enforcement, and automated archiving.</p>

  <p>
    <a href="#-key-features"><b>Key Features</b></a> •
    <a href="#-quick-start"><b>Quick Start</b></a> •
    <a href="#-downloads--releases"><b>Downloads</b></a> •
    <a href="#-architecture"><b>Architecture</b></a>
  </p>

</div>

---

## 🌟 Overview

**FileMint** is a native, high-speed Python desktop engine built for developers, system administrators, and security-conscious professionals who need to merge, organize, and archive complex file structures without relying on heavy external dependencies or cloud connectivity.

Operating entirely **offline and locally**, FileMint provides automated multi-segment regex versioning, dynamic compliance auditing, legacy version archiving, and single-click desktop integration for Linux (GNOME) and Windows environments.

---

## 🎯 Key Features

- **🔒 Zero-Dependency & Offline Security**: Runs natively on standard libraries or compiled C machine code with zero external network risks.
- **🚀 High-Performance C Compilation**: Compiled via Nuitka for instant startup and native x86_64 performance.
- **🏷️ Automated Regex Versioning**: Enforces strict `combined_vX.Y` or `merged_vX.Y` naming standards with dynamic auto-incrementing.
- **📦 Legacy Archiving System**: Automatically sweeps older versions into timestamped archive directories to maintain a pristine output folder.
- **🖥️ Theme-Responsive GUI**: Modern Tkinter dashboard with dynamic Light/Dark mode auto-scaling and persistent configuration storage.
- **🛠️ Integrated GNOME Launcher**: Includes one-click `install.sh` for native menu registration, desktop icons, and hicolor cache integration.

---

## 🚀 Quick Start

### Option 1: Run Pre-Compiled Binary (No Python Needed)
```bash
# Extract Linux Tarball package
tar -zxvf filemint_v15.0.tar.gz
cd FileMint-v15.0

# Launch standalone binary
./FileMint-v15.0
```

### Option 2: Native GNOME Desktop Installation
```bash
# Run automated installer
chmod +x installers/install.sh
./installers/install.sh
```
*Creates a system application launcher under **Office / Development** menu with native icon support.*

---
## 🏛️ Repository Architecture

```text
FileMint/
├── assets/                  # Header banner & UI screenshots
├── icons/                   # System desktop & app menu icons
├── installers/              # Linux install.sh & Windows install_windows.bat
├── documentation/           # Quick Start & User Guides
├── README.md                # Showcase Documentation
└── releases/                # Versioned release packages & SHA256 checksums
```

---

## 📦 Downloads & Releases

Pre-compiled production releases are verified with SHA-256 checksums:

| Release Package               | Target System              | SHA-256 Checksum                                                   |
|:------------------------------|:---------------------------|:-------------------------------------------------------------------|
| **`FileMint-v15.0`**          | Standalone Linux Binary    | `0b776432e575e343238570891c674295c11ba5f0b1747fe77a6080e30759b53c` |
| **`filemint_v15.0.tar.gz`**   | Linux POSIX Package        | `10e4c157b23c722d433360aabc1cccfce26c1e46d3f7c9aaeb2947b729937829` |
| **`filemint_v15.0.zip`**      | Cross-Platform Zip Archive | `bb41debacdb71669daba927ac18be272dea9000460bc641212d82dd33e2e15b4` |
---
### 🧩 Release (v15.0.5)

| Release Package               | Target System              | SHA-256 Checksum                                                   |
|:------------------------------|:---------------------------|:-------------------------------------------------------------------|
| **`FileMint-v15.0.5`**        | Standalone Linux Binary    | `f77e68e54f5e53dd603fb1b5e1ce142750d927656b1b4f16fe5e68a8b6a613b7` |
| **`filemint_v15.0.5.tar.gz`** | Linux POSIX Package        | `36c523761a46fe7040d29fda5b3397d26366fe7f851e8fb4b1fbdfe6a9f7b931` |
| **`filemint_v15.0.5.zip`**    | Cross-Platform Zip Archive | `598b9fe26dd3b6842ee5e3c4ef05558c64337b2e8e0b9b5220b1bdef1288d4b9` |

**Release Date:** `2026-09-19 19:59:56`
---
### 🧩 Release (v15.0.6)

| Release Package               | Target System              | SHA-256 Checksum                                                   |
|:------------------------------|:---------------------------|:-------------------------------------------------------------------|
| **`FileMint-v15.0.6`**        | Standalone Linux Binary    | `2c9c596cc4439776f2cdf26ef8b34182fab9c1538e7f5e63f89082b613c2a1f1` |
| **`filemint_v15.0.6.tar.gz`** | Linux POSIX Package        | `ebb0242d486abd3b907d16ce268be64b4445a1f081ca857afc8a16ebfbf259c5` |
| **`filemint_v15.0.6.zip`**    | Cross-Platform Zip Archive | `574dc0af7a382c5a39587c861d97f43b671007da925e78e2787d984a8698c54f` |

**Release Date:** `2026-09-19 22:30:10`
---
### 🧩 Release (v15.0.7)

| Release Package               | Target System              | SHA-256 Checksum                                                   |
|:------------------------------|:---------------------------|:-------------------------------------------------------------------|
| **`FileMint-v15.0.7`**        | Standalone Linux Binary    | `8a42ef511dae0548b5aec19a7b279950428779623cd52500332f7eb9ffc83eb1` |
| **`filemint_v15.0.7.tar.gz`** | Linux POSIX Package        | `b1070c72c9e7c6ebd9641ed87d7e8b0ebb4107ecf462498116e1121d5d937b8b` |
| **`filemint_v15.0.7.zip`**    | Cross-Platform Zip Archive | `b36b2a143acd072260589ba0af64a3f3cf4429b36f2e5f6c1e72e0da66ebef98` |

**Release Date:** `2026-09-20 00:09:22`
---
### 🧩 Release (v15.0.8)

| Release Package               | Target System              | SHA-256 Checksum                                                   |
|:------------------------------|:---------------------------|:-------------------------------------------------------------------|
| **`FileMint-v15.0.8`**        | Standalone Linux Binary    | `323a2ea7c15aaa2424b89964670abebbc1238682f96dad6e2a92db92609d919b` |
| **`filemint_v15.0.8.tar.gz`** | Linux POSIX Package        | `204498e40775b5719144c8133e53f8ffd311af84c6976902ee19874b2e79e177` |
| **`filemint_v15.0.8.zip`**    | Cross-Platform Zip Archive | `a4083d18e382c87e2b80029df2532d58582016645efe21ef14a21bbbe991bb4d` |

**Release Date:** `2026-09-20 18:03:22`
---
### 🧩 Release (v15.0.9)

| Release Package               | Target System              | SHA-256 Checksum                                                   |
|:------------------------------|:---------------------------|:-------------------------------------------------------------------|
| **`FileMint-v15.0.9`**        | Standalone Linux Binary    | `e1494495500d5ee14539a74d062fed6ab92c1f6a25035f01b5420109eabf824f` |
| **`filemint_v15.0.9.tar.gz`** | Linux POSIX Package        | `732fa4afb9ea319d8d0c59c3b4640fa1e278ede04c2ed1e91bdc36cf854d7e66` |
| **`filemint_v15.0.9.zip`**    | Cross-Platform Zip Archive | `844b40c59b5fbf940679ef844d170a7212c40d63ebebfa2391bd086fcf561aed` |

**Release Date:** `2026-09-20 19:35:02`

---

<div style="text-align: center;">
  <sub>Developed & Maintained for Secure, Offline Enterprise Operations</sub>
</div>

---
