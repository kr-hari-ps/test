#!/usr/bin/env bash
# ==============================================================================
# 🧮 FileMint Public Interactive Installer Engine (v15.0)
# Based on Baseline Engine v1.7 Specification
# ==============================================================================
set -e

# --- ANSI Styling Palette ---
GREEN='\033[0;92m'
BLUE='\033[0;94m'
YELLOW='\033[1;93m'
RED='\033[0;91m'
NC='\033[0m'
BOLD='\033[1m'

HICOLOR_SIZES=("16x16" "32x32" "48x48" "64x64" "128x128" "256x256" "512x512")

echo -e "${BLUE}${BOLD}=========================================================================${NC}"
echo -e "${BLUE}${BOLD}      ⚙️  FileMint Interactive Desktop Installer & Setup Engine (v15.0)    ${NC}"
echo -e "${BLUE}${BOLD}=========================================================================\n${NC}"

# Prompt for installation confirmation
read -r -p "$(echo -e " 📥 ${GREEN}${BOLD}Do you want to proceed with installing FileMint? (y/N): ${NC}")" choice
if [[ ! "$choice" =~ ^[Yy]$ ]]; then
    echo -e " 🛑 ${RED}${BOLD}[Cancel] Installation aborted by user.${NC}"
    exit 0
fi

# ------------------------------------------------------------------------------
# 1. OS Environment & Pre-Flight Dependency Audit
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}🔍 Step 1: Auditing System Environment & OS Compatibility...${NC}"

if [ -f /etc/os-release ]; then
    . /etc/os-release
    echo -e "   -> Detected OS: ${GREEN}${NAME} ${VERSION}${NC}"
else
    echo -e "   -> ${YELLOW}Warning: Unknown OS distribution. Proceeding with standard POSIX checks.${NC}"
fi

# Check CLI utilities
MISSING_DEPS=()
for cmd in tar zip update-desktop-database; do
    if ! command -v "$cmd" &> /dev/null; then
        MISSING_DEPS+=("$cmd")
    fi
done

if [ ${#MISSING_DEPS[@]} -gt 0 ]; then
    echo -e "   -> ${YELLOW}Warning: Missing optional utilities: ${MISSING_DEPS[*]}${NC}"
    echo -e "      Refer to README.md for complete dependency installation steps."
fi

# Check Python environment
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ [Fatal Error] Python3 is not installed on this system.${NC}"
    echo -e "${RED}   Please install Python3 before proceeding or refer to README.md.${NC}\n"
    exit 1
fi
echo -e "   -> Python3 Version: ${GREEN}$(python3 --version)${NC}"

# Check Tkinter
if ! python3 -c "import tkinter" &> /dev/null; then
    echo -e "   -> ${YELLOW}⚠ Warning: Python Tkinter GUI library was not detected on this environment.${NC}"
    echo -e "      Installation commands to enable Tkinter:"
    echo -e "        - Debian/Ubuntu:  ${BOLD}sudo apt install python3-tk${NC}"
    echo -e "        - Fedora/RHEL:    ${BOLD}sudo dnf install python3-tkinter${NC}"
    echo -e "        - Arch Linux:     ${BOLD}sudo pacman -S tk${NC}"
    read -r -p "$(echo -e "   ${BLUE}❔ Proceed with desktop installation anyway? (y/N): ${NC}")" tk_choice
    if [[ ! "$tk_choice" =~ ^[Yy]$ ]]; then
        echo -e "${RED}🛑 Installation aborted by user. Please install Tkinter and retry or check README.md.${NC}\n"
        exit 1
    fi
else
    echo -e "   -> ${GREEN}✔ Tkinter library detected successfully.${NC}"
fi

# ------------------------------------------------------------------------------
# 2. Interactive Target Directory Configuration
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}📁 Step 2: Configure Target Installation & System Folders${NC}"

HOME_DIR="$HOME"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
ICON_BASE_DIR="$HOME_DIR/.local/share/icons"
HICOLOR_DIR="$ICON_BASE_DIR/hicolor"
DESKTOP_APPS_DIR="$HOME_DIR/.local/share/applications"
DEFAULT_INSTALL_DIR="$HOME_DIR/.local/share/filemint-app"
DEFAULT_APPDATA_DIR="$HOME_DIR/.config/filemint-app"
DEFAULT_OUTPUT_DIR="$HOME_DIR/Documents/FileMint/Output"
DEFAULT_ARCHIVE_DIR="$HOME_DIR/Documents/FileMint/Archive"


read -rp "$(echo -e "   Application Install Directory [Default: ${BLUE}$DEFAULT_INSTALL_DIR${NC}] (hit ⤶ to accept):\n   > ")" USER_INSTALL_DIR
APP_INSTALL_DIR="${USER_INSTALL_DIR:-$DEFAULT_INSTALL_DIR}"

read -rp "$(echo -e "   Configuration Path Directory [Default: ${BLUE}$DEFAULT_APPDATA_DIR${NC}] (hit ⤶ to accept):\n   > ")" USER_APPDATA_DIR
APPDATA_DIR="${USER_APPDATA_DIR:-$DEFAULT_APPDATA_DIR}"

read -rp "$(echo -e "   Default Output Directory [Default: ${BLUE}$DEFAULT_OUTPUT_DIR${NC}] (hit ⤶ to accept):\n   > ")" USER_OUTPUT_DIR
OUTPUT_DIR="${USER_OUTPUT_DIR:-$DEFAULT_OUTPUT_DIR}"

read -rp "$(echo -e "   Default Archive Directory [Default: ${BLUE}$DEFAULT_ARCHIVE_DIR${NC}] (hit ⤶ to accept):\n   > ")" USER_ARCHIVE_DIR
ARCHIVE_DIR="${USER_ARCHIVE_DIR:-$DEFAULT_ARCHIVE_DIR}"

# ------------------------------------------------------------------------------
# 3. Interactive File Exclusion Configuration
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}🛠️ Step 3: Configure File Operations & Exclusions${NC}"
read -rp "$(echo -e "   Enter file extensions to exclude (comma-separated, e.g. .tmp,.log,.pyc,.bak) [Default: none]: ")" EXCLUDE_INPUT

EXCLUDED_JSON_ARRAY="[]"
if [ -n "$EXCLUDE_INPUT" ]; then
    EXCLUDED_JSON_ARRAY=$(python3 -c "import sys, json; print(json.dumps([x.strip() for x in sys.argv[1].split(',') if x.strip()]))" "$EXCLUDE_INPUT")
fi

# ------------------------------------------------------------------------------
# 4. Generate Dynamic Configuration Files (`appConfig.json` & `fileOpsConfig.json`)
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}📝 Step 4: Generating Dynamic App & Operations Config Templates...${NC}"
mkdir -p "$APPDATA_DIR" "$APP_INSTALL_DIR" "$OUTPUT_DIR" "$ARCHIVE_DIR"

cat <<EOF > "$APPDATA_DIR/appConfig.json"
{
  "app_metadata": {
    "name": "FileMint",
    "version": "15.0.0",
    "icon_filename": "filemint.png",
    "window_title": "FileMint - File Consolidation & Archiving Engine"
  },
  "directories": {
    "HOME": "$HOME_DIR",
    "DESKTOP_DIR": "$HOME_DIR/Desktop",
    "DESKTOP_APPS_DIR": "$HOME_DIR/.local/share/applications",
    "ICON_DIR": "$HOME_DIR/.local/share/icons",
    "DOCUMENTS_DIR": "$HOME_DIR/Documents",
    "APPDATA_DIR": "$APPDATA_DIR",
    "APP_INSTALL_DIR": "$APP_INSTALL_DIR",
    "DEFAULT_OUTPUT_DIR": "$OUTPUT_DIR",
    "DEFAULT_ARCHIVE_DIR": "$ARCHIVE_DIR"
  },
  "rules": {
    "strict_pattern": "^(combined|merged|merge) *(.+?)* [vV](\\\\d+(?:\\\\.\\\\d+){1,3})\\\\.txt$",
    "default_theme": "light"
  }
}
EOF

cat <<EOF > "$APPDATA_DIR/fileOpsConfig.json"
{
  "excluded_items": $EXCLUDED_JSON_ARRAY,
  "output_dir": "$OUTPUT_DIR",
  "archive_dir": "$ARCHIVE_DIR"
}
EOF
echo -e "   -> ${GREEN}✔ Configuration templates generated in $APPDATA_DIR${NC}"

# ==============================================================================
# Step 4/5: Deploy Standalone Binary Executable & Core Files
# ==============================================================================
echo -e "\n${BOLD}🛠️Deploying application binaries and configurations...${NC}"

# Ensure target installation directory exists
mkdir -p "$APP_INSTALL_DIR"

# 1. Locate and copy standalone binary executable from releases/
INSTALLED_BIN=""
if [ -d "$REPO_ROOT/releases" ]; then
    # Find pre-compiled binary (matches FileMint-v* while excluding archives/sums)
    BIN_FILE=$(find "$REPO_ROOT/releases" -maxdepth 1 -type f \
      -name "FileMint-*" ! -name "*.zip" ! -name "*.tar.gz" ! -name "*.txt" | head -n 1)

    if [ -n "$BIN_FILE" ] && [ -f "$BIN_FILE" ]; then
        BIN_NAME=$(basename "$BIN_FILE")
        cp -f "$BIN_FILE" "$APP_INSTALL_DIR/$BIN_NAME"
        chmod +x "$APP_INSTALL_DIR/$BIN_NAME"
        INSTALLED_BIN="$APP_INSTALL_DIR/$BIN_NAME"
         echo -e "   -> ${GREEN}✔ Deployed pre-compiled binary: $INSTALLED_BIN.${NC}"
    elif [ -z "$INSTALLED_BIN" ]; then
        echo -e "   -> ${YELLOW}ℹ No pre-compiled binary found in $REPO_ROOT/releases/${NC}"
        if [ -d "$REPO_ROOT/src" ]; then
            cp -rf "$REPO_ROOT/src/"* "$APP_INSTALL_DIR/src/" 2>/dev/null || true
        elif [ -f "$REPO_ROOT/filemint.py" ]; then
            mkdir -p "$APP_INSTALL_DIR/src"
            cp -f "$REPO_ROOT/"*.py "$APP_INSTALL_DIR/src/" 2>/dev/null || true
        fi
        chmod +x "$APP_INSTALL_DIR/src/filemint.py" 2>/dev/null || true
        echo -e "   -> ${YELLOW}ℹ Deployed Python source scripts as fallback.${NC}"
    fi
fi

# 2. Copy configuration files if present
if [ -d "$REPO_ROOT/config" ]; then
    mkdir -p "$APPDATA_DIR"
    cp -f "$REPO_ROOT/config/"*.json "$APPDATA_DIR/" 2>/dev/null || true
    echo -e "   -> ${GREEN}✔ Deployed configuration blueprints to $APPDATA_DIR.${NC}"
fi

# ------------------------------------------------------------------------------
# 5. Deploy Icon Assets & Audit Hicolor Path Structure
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}🎨 Step 5: Auditing Icon Paths & Deploying Hicolor Multi-Resolution Icons...${NC}"

if [ ! -d "$HICOLOR_DIR" ]; then
    echo -e "   -> ${YELLOW}⚠ Warning: System hicolor icon theme directory not found at $HICOLOR_DIR.${NC}"
    echo -e "   -> Creating custom hicolor directory structure automatically."
fi


ICON_SRC=""
if [ -f "$REPO_ROOT/assets/icons/filemint.png" ]; then
    ICON_SRC="$REPO_ROOT/assets/icons/filemint.png"
elif [ -f "$REPO_ROOT/icons/filemint.png" ]; then
    ICON_SRC="$REPO_ROOT/icons/filemint.png"
elif [ -f "$REPO_ROOT/filemint.png" ]; then
    ICON_SRC="$REPO_ROOT/filemint.png"
fi

if [ -n "$ICON_SRC" ]; then
    mkdir -p "$ICON_BASE_DIR"
    cp -f "$ICON_SRC" "$ICON_BASE_DIR/filemint.png"
    
    for size in "${HICOLOR_SIZES[@]}"; do
        target_path="$HICOLOR_DIR/$size/apps"
        mkdir -p "$target_path"
        cp -f "$ICON_SRC" "$target_path/filemint.png"
    done
    echo -e "   -> ${GREEN}✔ Icons successfully deployed across 7 hicolor resolutions (16x16 -> 512x512)${NC}"
else
    echo -e "   -> ${YELLOW}⚠ Warning: 'filemint.png' icon not found in package root ($REPO_ROOT). Refer to README.md.${NC}"
fi

# ------------------------------------------------------------------------------
# 6. Deploy Executable & Register GNOME Shortcut
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}🖥️ Step 6: Deploying Application Executables & Registering GNOME Shortcut...${NC}"

if [ -n "$INSTALLED_BIN" ] && [ -x "$INSTALLED_BIN" ]; then
    EXEC_CMD="$INSTALLED_BIN"
elif [ -f "$APP_INSTALL_DIR/src/filemint.py" ]; then
    EXEC_CMD="python3 $APP_INSTALL_DIR/src/filemint.py"
else
    EXEC_CMD="python3 $APP_INSTALL_DIR/filemint.py"
fi


mkdir -p "$APP_INSTALL_DIR/src" "$APP_INSTALL_DIR/config" "$APP_INSTALL_DIR/icons"

mkdir -p "$DESKTOP_APPS_DIR"

cat <<EOF > "$DESKTOP_APPS_DIR/filemint.desktop"
[Desktop Entry]
Version=1.0
Type=Application
Name=FileMint
GenericName=File Consolidation & Archiving Engine
Comment=Offline zero-dependency data sanitization and archiving engine
Exec=$EXEC_CMD
Path=$APP_INSTALL_DIR
Icon=filemint
Terminal=false
Categories=Utility;Development;Archiving;
StartupNotify=true
StartupWMClass=FileMint
Keywords=filemint;merge;combine;archive;consolidate;version;
EOF

chmod +x "$DESKTOP_APPS_DIR/filemint.desktop"

# Refresh GNOME application launcher and GTK icon cache
if command -v update-desktop-database &> /dev/null; then
    echo -e "   -> 🔄 Refreshing local desktop application indexing registry..."
    update-desktop-database "$DESKTOP_APPS_DIR" || true
fi

 echo -e "   -> ${GREEN}✔ Registered desktop shortcut launching: $EXEC_CMD.${NC}"

if command -v gtk-update-icon-cache &> /dev/null; then
    echo -e "   -> 🔄 Refreshing GTK system icon cache database..."
    gtk-update-icon-cache -f -t "$ICON_BASE_DIR" || true
    gtk-update-icon-cache -f -t "$HICOLOR_DIR" || true
fi

 echo -e "   -> ${GREEN}✔ Icon Cache database updated.${NC}"
# ------------------------------------------------------------------------------
# 7. Summary & Installation Complete
# ------------------------------------------------------------------------------
echo -e "\n${GREEN}${BOLD}=========================================================================${NC}"
echo -e "${GREEN}${BOLD}  🎉 FileMint v15.0 Installation Successfully Completed!               ${NC}"
echo -e "${GREEN}${BOLD}=========================================================================${NC}"
echo -e "📁 App Directory:       ${BLUE}$APP_INSTALL_DIR${NC}"
echo -e "⚙️ Configuration Path:   ${BLUE}$APPDATA_DIR${NC}"
echo -e "🖥️ Desktop Shortcut:    ${BLUE}$DESKTOP_APPS_DIR/filemint.desktop${NC}"
echo -e "🎨 System Icon:         ${BLUE}$ICON_BASE_DIR/filemint.png${NC}"
echo -e "\n👉 You can launch FileMint from your GNOME Applications Overview."
echo -e "💡 If you encounter any execution issues, please refer to ${BOLD}README.md${NC}."
echo -e "${GREEN}${BOLD}=========================================================================\n${NC}"
